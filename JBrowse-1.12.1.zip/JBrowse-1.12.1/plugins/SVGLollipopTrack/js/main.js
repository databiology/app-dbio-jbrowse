//>>built
define("SVGLollipopTrack/main",[],1);
//# sourceMappingURL=main.js.map