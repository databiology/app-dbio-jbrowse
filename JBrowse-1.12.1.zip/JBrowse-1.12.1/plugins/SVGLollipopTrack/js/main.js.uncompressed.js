define("SVGLollipopTrack/main", [], 1);
