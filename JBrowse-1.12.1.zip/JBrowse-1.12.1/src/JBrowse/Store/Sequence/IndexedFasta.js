// renamed
define( "JBrowse/Store/Sequence/IndexedFasta", [ 'JBrowse/Store/SeqFeature/IndexedFasta' ], function(s) { return s; } );
