// renamed
define( "JBrowse/Store/Sequence/TwoBit", [ 'JBrowse/Store/SeqFeature/TwoBit' ], function(s) { return s; } );
