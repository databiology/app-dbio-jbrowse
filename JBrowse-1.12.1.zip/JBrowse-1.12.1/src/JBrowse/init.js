require( {
           packages: [
               'dbind',
               'dgrid',
               'dojo',
               'dijit',
               'dojox',
               'json-schema',
               'jszlib',
               { name: 'lazyload', main: 'lazyload' },
               'xstyle',
               'put-selector',
               { name: 'jDataView', location: 'jDataView/src', main: 'jdataview' },
               'FileSaver',
               'JBrowse'
           ]
         }
);
