define(
"dijit/form/nls/az/ComboBox", ({
	"previousMessage" : "Əvvəlki variantlar",
	"nextMessage" : "Başqa variantlar"
})
);
