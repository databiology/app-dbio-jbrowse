define("dijit/_editor/nls/sr/LinkDialog", {      
//begin v1.x content
	createLinkTitle: "Svojstva linka",
	insertImageTitle: "Svojstva slike",
	url: "URL:",
	text: "Opis:",
	target: "Cilj:",
	set: "Podesi:",
	currentWindow: "Aktuelni prozor",
	parentWindow: "Nadređeni prozor",
	topWindow: "Najviši prozor",
	newWindow: "Novi prozor"
//end v1.x content
});

