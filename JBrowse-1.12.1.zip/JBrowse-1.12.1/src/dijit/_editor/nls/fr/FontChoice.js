define(
"dijit/_editor/nls/fr/FontChoice", ({
	fontSize: "Taille",
	fontName: "Police",
	formatBlock: "Mise en forme",
	serif: "serif",
	"sans-serif": "sans serif",
	monospace: "espacement fixe",
	cursive: "cursive",
	fantasy: "fantaisie",
	noFormat: "Néant",
	p: "Paragraphe",
	h1: "En-tête",
	h2: "Sous-en-tête",
	h3: "Sous-sous-en-tête",
	pre: "Pré-mise en forme",
	1: "très très petite",
	2: "très petite",
	3: "petite",
	4: "moyenne",
	5: "grande",
	6: "très grande",
	7: "très très grande"
})
);
